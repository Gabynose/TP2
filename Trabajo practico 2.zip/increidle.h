#ifndef __INCREIDLE_H__
#define __INCREIDLE_H__
#include <stdbool.h>
#define MAX_CONTRASENIA 6
void increidle(char* contrasenia);
#endif /* __INCREIDLE_H__ */