#include "kronos.h"
#include "increidle.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
static const char ELASTIC = 'E';
static const char VIOLETA = 'V';
static const char DASH = 'D';
static const char MR_INCREIBLE = 'M';
static const char ROBOT = 'R';
static const char SUPERTRAJE = 'T';
static const char PINZA = 'P';
static const char ESPACIO_LIBRE = ' ';
static const char ARRIBA = 'W';
static const char ABAJO = 'S';
static const char IZQUIERDA = 'A';
static const char DERECHA = 'D';
static const char ACTIVAR_SUPERTRAJE = 'F';
static const char LASER = 'L';
#define MAX_FILA 20
#define MAX_COLUMNA 20
#define MIN_COLUMNA 0
#define MIN_FILA 0
#define ID_ELASTIC 0
#define ID_VIOLETA 1
#define ID_DASH 2
#define ID_MR_INCREIBLE 3
#define CUADRANTE_1 1
#define CUADRANTE_2 2
#define CUADRANTE_3 3
#define CUADRANTE_4 4
#define PERDISTE -1
#define GANASTE 1
#define EN_CURSO 0
#define MOVS_CON_PODER 5
#define MOVS_ELASTIC 25
#define MOVS_VIOLETA 30
#define MOVS_DASH 20
#define MOVS_MR_INCREBILE 15
#define POSICION_INVALIDA -1
#define PRIMER_ROBOT 0
#define SEGUNDO_ROBOT 1
#define TERCER_ROBOT 2
#define CUARTO_ROBOT 3
#define PRIMER_TRAJE 0
#define SEGUNDO_TRAJE 1
#define TERCER_TRAJE 2
#define CUARTO_TRAJE 3
#define PINZAS_LIMITE_CUADRANTE_1 4
#define PINZAS_LIMITE_CUADRANTE_2 8
#define PINZAS_LIMITE_CUADRANTE_3 12
#define PINZAS_LIMITE_CUADRANTE_4 16

enum { POS_1,
    POS_2,
    POS_3,
    POS_4 };

/*/ PRE: 
    POST: Cambia tope_lasers si se adivina la contrasenia o no se adivina
/*/
void verificar_contrasenia_completa(bool contrasenia_completa, int* tope_lasers)
{
    if (contrasenia_completa) {
        (*tope_lasers) = 6;
    } else {
        (*tope_lasers) = 10;
    }
}
/*/ PRE:
    POST: Devuelve una posicion random entre 0 y 3.
/*/
int sacar_posicion_random_laser()
{
    int posicion;
    posicion = (rand() % (3 - 0 + 1)) + 0;
    return posicion;
}
/*/PRE:
   POST: Le asigna a cada robot su respectivo tope_lasers.
/*/
void inicializar_tope_lasers_en_robots(robot_t robots[MAX_ROBOTS], int tope_robots, int* tope_lasers)
{
    for (int i = 0; i < tope_robots; i++) {
        robots[i].tope_lasers = *tope_lasers;
    }
}
/*/ PRE: Robots tienen que estar en una posicion valida, tope_robots < 0
    POST: Inicializa las posiciones de los lasers de los robots de manera aleatoria
/*/
void inicializar_lasers(robot_t robots[MAX_ROBOTS], int* tope_lasers, int tope_robots, bool contrasenia_completa)
{
    for (int j = 0; j < MAX_ROBOTS; j++) {
        for (int i = 0; i < MAX_LASERS; i++) {
            robots[j].lasers[i].columna = -1;
            robots[j].lasers[i].columna = -1;
        }

        robots[j].tope_lasers = 0;
    }
    (*tope_lasers) = 0;
    verificar_contrasenia_completa(contrasenia_completa, tope_lasers);
    inicializar_tope_lasers_en_robots(robots, tope_robots, tope_lasers);
    for (int j = 0; j < tope_robots; j++) {
        int posicion = sacar_posicion_random_laser();
        int valor = 1;
        for (int i = 0; i < *tope_lasers / 2; i++) {
            if (posicion == POS_1) {
                robots[j].lasers[i].fila = robots[j].posicion.fila + valor;
                robots[j].lasers[i].columna = robots[j].posicion.columna;
                valor++;
            } else if (posicion == POS_2) {
                robots[j].lasers[i].fila = robots[j].posicion.fila - valor;
                robots[j].lasers[i].columna = robots[j].posicion.columna;
                valor++;
            } else if (posicion == POS_3) {
                robots[j].lasers[i].fila = robots[j].posicion.fila + valor;
                robots[j].lasers[i].columna = robots[j].posicion.columna;
                valor++;
            } else if (posicion == POS_4) {
                robots[j].lasers[i].fila = robots[j].posicion.fila - valor;
                robots[j].lasers[i].columna = robots[j].posicion.columna;
                valor++;
            }
        }
        valor = 1;
        for (int i = *tope_lasers / 2; i < *tope_lasers; i++) {
            if (posicion == POS_1) {
                robots[j].lasers[i].fila = robots[j].posicion.fila;
                robots[j].lasers[i].columna = robots[j].posicion.columna - valor;
                valor++;
            } else if (posicion == POS_2) {
                robots[j].lasers[i].fila = robots[j].posicion.fila;
                robots[j].lasers[i].columna = robots[j].posicion.columna + valor;
                valor++;
            } else if (posicion == POS_3) {
                robots[j].lasers[i].fila = robots[j].posicion.fila;
                robots[j].lasers[i].columna = robots[j].posicion.columna + valor;
                valor++;
            } else if (posicion == POS_4) {
                robots[j].lasers[i].fila = robots[j].posicion.fila;
                robots[j].lasers[i].columna = robots[j].posicion.columna - valor;
                valor++;
            }
        }
    }
}

/*/ PRE: Robot tiene que estar en una posicion valida.
    POST: Mueve los primeros mitad de lasers del robot.  
/*/

void mover_primer_laser(robot_t* robot)
{
    if (robot->posicion.fila + 1 == robot->lasers[0].fila && robot->posicion.columna == robot->lasers[0].columna) {
        int valor = robot->posicion.columna;
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            valor--;
            robot->lasers[i].columna = valor;
        }
    } else if (robot->posicion.fila - 1 == robot->lasers[0].fila && robot->posicion.columna == robot->lasers[0].columna) {
        int valor = robot->posicion.columna;
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            valor++;
            robot->lasers[i].columna = valor;
        }
    } else if (robot->posicion.columna + 1 == robot->lasers[0].columna && robot->posicion.fila == robot->lasers[0].fila) {
        int valor = robot->posicion.fila;
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            valor++;
            robot->lasers[i].fila = valor;
        }
    } else if (robot->posicion.columna - 1 == robot->lasers[0].columna && robot->posicion.fila == robot->lasers[0].fila) {
        int valor = robot->posicion.fila;
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            valor--;
            robot->lasers[i].fila = valor;
        }
    } else if (robot->posicion.fila - 1 == robot->lasers[0].fila && robot->posicion.columna + 1 == robot->lasers[0].columna) { /* DIAGONALES */
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            robot->lasers[i].fila = robot->posicion.fila;
        }
    } else if (robot->posicion.fila + 1 == robot->lasers[0].fila && robot->posicion.columna + 1 == robot->lasers[0].columna) {
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            robot->lasers[i].columna = robot->posicion.columna;
        }
    } else if (robot->posicion.fila + 1 == robot->lasers[0].fila && robot->posicion.columna - 1 == robot->lasers[0].columna) {
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            robot->lasers[i].fila = robot->posicion.fila;
        }
    } else if (robot->posicion.fila - 1 == robot->lasers[0].fila && robot->posicion.columna - 1 == robot->lasers[0].columna) {
        for (int i = 0; i < robot->tope_lasers / 2; i++) {
            robot->lasers[i].columna = robot->posicion.columna;
        }
    }
}
/*/PRE: Robot tiene que estar en una posicion valida.
   POST: Mueve la segunda mitad lasers del robot. 
/*/
void mover_segundo_laser(robot_t* robot)
{
    if (robot->posicion.fila + 1 == robot->lasers[robot->tope_lasers / 2].fila && robot->posicion.columna == robot->lasers[robot->tope_lasers / 2].columna) {
        int valor = robot->posicion.columna;
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            valor--;
            robot->lasers[i].columna = valor;
        }
    } else if (robot->posicion.fila - 1 == robot->lasers[robot->tope_lasers / 2].fila && robot->posicion.columna == robot->lasers[robot->tope_lasers / 2].columna) {
        int valor = robot->posicion.columna;
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            valor++;
            robot->lasers[i].columna = valor;
        }
    } else if (robot->posicion.columna + 1 == robot->lasers[robot->tope_lasers / 2].columna && robot->posicion.fila == robot->lasers[robot->tope_lasers / 2].fila) {
        int valor = robot->posicion.fila;
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            valor++;
            robot->lasers[i].fila = valor;
        }
    } else if (robot->posicion.columna - 1 == robot->lasers[robot->tope_lasers / 2].columna && robot->posicion.fila == robot->lasers[robot->tope_lasers / 2].fila) {
        int valor = robot->posicion.fila;
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            valor--;
            robot->lasers[i].fila = valor;
        }
    } else if (robot->posicion.fila - 1 == robot->lasers[robot->tope_lasers / 2].fila && robot->posicion.columna + 1 == robot->lasers[robot->tope_lasers / 2].columna) { /* DIAGONALES */
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            robot->lasers[i].fila = robot->posicion.fila;
        }
    } else if (robot->posicion.fila + 1 == robot->lasers[robot->tope_lasers / 2].fila && robot->posicion.columna + 1 == robot->lasers[robot->tope_lasers / 2].columna) {
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            robot->lasers[i].columna = robot->posicion.columna;
        }
    } else if (robot->posicion.fila + 1 == robot->lasers[robot->tope_lasers / 2].fila && robot->posicion.columna - 1 == robot->lasers[robot->tope_lasers / 2].columna) {
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            robot->lasers[i].fila = robot->posicion.fila;
        }
    } else if (robot->posicion.fila - 1 == robot->lasers[robot->tope_lasers / 2].fila && robot->posicion.columna - 1 == robot->lasers[robot->tope_lasers / 2].columna) {
        for (int i = robot->tope_lasers / 2; i <= robot->tope_lasers; i++) {
            robot->lasers[i].columna = robot->posicion.columna;
        }
    }
}
/*/ PRE: tope_robots > 0
    POST: Mueve todos los lasers de un robot.

/*/
void mover_lasers(robot_t robots[MAX_ROBOTS], int tope_robots)
{
    for (int i = 0; i < tope_robots; i++) {
        mover_primer_laser(&robots[i]);
        mover_segundo_laser(&robots[i]);
    }
}

/*/ PRE: 
    POST: Inicializa 4 robots en sus respectivos limites.
/*/
void inicializar_robots(robot_t robots[MAX_ROBOTS], int* tope_robots)
{
    robots[PRIMER_ROBOT].posicion.fila = POSICION_INVALIDA;
    robots[PRIMER_ROBOT].posicion.columna = POSICION_INVALIDA;
    robots[PRIMER_ROBOT].posicion.fila = (rand() % (9 - 0 + 1)) + 0;
    robots[PRIMER_ROBOT].posicion.columna = (rand() % (9 - 0 + 1)) + 0;

    robots[SEGUNDO_ROBOT].posicion.fila = POSICION_INVALIDA;
    robots[SEGUNDO_ROBOT].posicion.columna = POSICION_INVALIDA;
    robots[SEGUNDO_ROBOT].posicion.fila = (rand() % (9 - 0 + 1)) + 0;
    robots[SEGUNDO_ROBOT].posicion.columna = (rand() % (19 - 10 + 1)) + 10;

    robots[TERCER_ROBOT].posicion.fila = POSICION_INVALIDA;
    robots[TERCER_ROBOT].posicion.columna = POSICION_INVALIDA;
    robots[TERCER_ROBOT].posicion.fila = (rand() % (19 - 10 + 1)) + 10;
    robots[TERCER_ROBOT].posicion.columna = (rand() % (9 - 0 + 1)) + 0;

    robots[CUARTO_ROBOT].posicion.fila = POSICION_INVALIDA;
    robots[CUARTO_ROBOT].posicion.columna = POSICION_INVALIDA;
    robots[CUARTO_ROBOT].posicion.fila = (rand() % (19 - 10 + 1)) + 10;
    robots[CUARTO_ROBOT].posicion.columna = (rand() % (19 - 10 + 1)) + 10;

    *tope_robots = 4;

}
/*/ PRE: tope_robots > 0 && tope_lasers > 0 | Robots tienen que estar en una posicion valida
    POST: Devuelve false si hay superposicion de un personaje con algun laser o robot.
/*/
bool es_posicion_correcta_personaje(robot_t robots[MAX_ROBOTS], int tope_robots, int fila, int columna)
{
    for (int i = 0; i < tope_robots; i++) {
        if (robots[i].posicion.columna == columna && robots[i].posicion.fila == fila) {
            return false;
        }

        for (int j = 0; j < robots[i].tope_lasers; j++) {
            if (robots[i].lasers[j].columna == columna && robots[i].lasers[j].fila == fila) {
                return false;
            }
        }
    }

    return true;
}

/*/PRE: Robot inicializado en una posicion valida, tope_robots > 0.
   POST: Inicializa a Elastic Girl en una posicion valida con sus respectivas estadisticas.
/*/
void inicializar_elastic(personaje_t* personaje, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    personaje->posicion.fila = POSICION_INVALIDA;
    personaje->posicion.columna = POSICION_INVALIDA;
    personaje->movimientos = MOVS_ELASTIC;
    personaje->movimientos_con_poder = MOVS_CON_PODER;
    personaje->cuadrante_inicial = 1;

    int fila = (rand() % (9 - 0 + 1)) + 0;
    int columna = (rand() % (9 - 0 + 1)) + 0;
    while (!es_posicion_correcta_personaje(robots, tope_robots, fila, columna)) {
        fila = (rand() % (9 - 0 + 1)) + 0;
        columna = (rand() % (9 - 0 + 1)) + 0;
    }
    personaje->posicion.fila = fila;
    personaje->posicion.columna = columna;
}
/*/PRE: Robot inicializado en una posicion valida, tope_robots > 0.
   POST: Inicializa a Violeta en una posicion valida con sus respectivas estadisticas.
/*/
void inicializar_violeta(personaje_t* personaje, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    personaje->posicion.fila = POSICION_INVALIDA;
    personaje->posicion.columna = POSICION_INVALIDA;
    personaje->movimientos = MOVS_VIOLETA;
    personaje->movimientos_con_poder = MOVS_CON_PODER;
    personaje->cuadrante_inicial = 2;

    int fila = (rand() % (9 - 0 + 1)) + 0;
    int columna = (rand() % (19 - 10 + 1)) + 10;
    while (!es_posicion_correcta_personaje(robots, tope_robots, fila, columna)) {
        fila = (rand() % (9 - 0 + 1)) + 0;
        columna = (rand() % (19 - 10 + 1)) + 10;
    }
    personaje->posicion.fila = fila;
    personaje->posicion.columna = columna;
}
/*/PRE: Robot inicializado en una posicion valida, tope_robots > 0.
   POST: Inicializa a Dash en una posicion valida con sus respectivas estadisticas.
/*/
void inicializar_dash(personaje_t* personaje, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    personaje->posicion.fila = POSICION_INVALIDA;
    personaje->posicion.columna = POSICION_INVALIDA;
    personaje->movimientos = MOVS_DASH;
    personaje->movimientos_con_poder = MOVS_CON_PODER;
    personaje->cuadrante_inicial = 3;

    int fila = (rand() % (19 - 10 + 1)) + 10;
    int columna = (rand() % (9 - 0 + 1)) + 0;
    while (!es_posicion_correcta_personaje(robots, tope_robots, fila, columna)) {
        fila = (rand() % (19 - 10 + 1)) + 10;
        columna = (rand() % (9 - 0 + 1)) + 0;
    }
    personaje->posicion.fila = fila;
    personaje->posicion.columna = columna;
}
/*/PRE: Robot inicializado en una posicion valida, tope_robots > 0.
   POST: Inicializa a Mr Increible en una posicion valida con sus respectivas estadisticas.
/*/
void inicializar_increible(personaje_t* personaje, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    personaje->posicion.fila = POSICION_INVALIDA;
    personaje->posicion.columna = POSICION_INVALIDA;
    personaje->movimientos = MOVS_MR_INCREBILE;
    personaje->movimientos_con_poder = MOVS_CON_PODER;
    personaje->cuadrante_inicial = 4;

    int fila = (rand() % (19 - 10 + 1)) + 10;
    int columna = (rand() % (19 - 10 + 1)) + 10;
    while (!es_posicion_correcta_personaje(robots, tope_robots, fila, columna)) {
        fila = (rand() % (19 - 10 + 1)) + 10;
        columna = (rand() % (19 - 10 + 1)) + 10;
    }
    personaje->posicion.fila = fila;
    personaje->posicion.columna = columna;
}

/*/ PRE: Robots inicializados previamente con sus lasers y tope_robots valido.
    POST: Inicializa todos los personajes en conjunto.
/*/
void inicializar_personajes(personaje_t personajes[MAX_PERSONAJES], int* tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    inicializar_elastic(&personajes[ID_ELASTIC], robots, tope_robots);

    inicializar_violeta(&personajes[ID_VIOLETA], robots, tope_robots);

    inicializar_dash(&personajes[ID_DASH], robots, tope_robots);

    inicializar_increible(&personajes[ID_MR_INCREIBLE], robots, tope_robots);

    *tope_personajes = 4;
}

/*/ PRE: Posicion de personajes valida && Posicion de robots valida && tope_personajes > 0 && tope_robots > 0.
    POST: Devuelve true o false dependiendo si hay superposicion de trajes en algun personaje o robot.
/*/
bool es_posicion_traje_correcta(personaje_t personajes[MAX_PERSONAJES], int tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots, int columna, int fila)
{
    for (int i = 0; i < tope_personajes; i++) {
        if (personajes[i].posicion.columna == columna && personajes[i].posicion.fila == fila) {
            return false;
        }
    }

    for (int i = 0; i < tope_robots; i++) {
        if (robots[i].posicion.columna == columna && robots[i].posicion.fila == fila) {
            return false;
        }
    }

    return true;
}
/*/ PRE: 
    POST: Inicializa primer traje en el primer cuadrante.
/*/
void inicializar_traje_primer_cuadrante(supertraje_t supertrajes[MAX_SUPERTRAJES], int* tope_supertraje, robot_t robots[MAX_ROBOTS], int tope_robots, personaje_t personajes[MAX_PERSONAJES], int tope_personajes)
{
    supertrajes[PRIMER_TRAJE].posicion.fila = POSICION_INVALIDA;
    supertrajes[PRIMER_TRAJE].posicion.columna = POSICION_INVALIDA;
    supertrajes[PRIMER_TRAJE].recolectado = false;
    supertrajes[PRIMER_TRAJE].usado = false;
    supertrajes[PRIMER_TRAJE].cuadrante = CUADRANTE_1;

    int fila = (rand() % (9 - 0 + 1)) + 0;
    int columna = (rand() % (9 - 0 + 1)) + 0;
    while (!es_posicion_traje_correcta(personajes, tope_personajes, robots, tope_robots, columna, fila)) {
        fila = (rand() % (9 - 0 + 1)) + 0;
        columna = (rand() % (9 - 0 + 1)) + 0;
    }

    supertrajes[PRIMER_TRAJE].posicion.columna = columna;
    supertrajes[PRIMER_TRAJE].posicion.fila = fila;

    (*tope_supertraje)++;
}
/*/ PRE: 
    POST: Inicializa segundo traje en el segundo cuadrante.
/*/
void inicializar_traje_segundo_cuadrante(supertraje_t supertrajes[MAX_SUPERTRAJES], int* tope_supertraje, robot_t robots[MAX_ROBOTS], int tope_robots, personaje_t personajes[MAX_PERSONAJES], int tope_personajes)
{
    supertrajes[SEGUNDO_TRAJE].posicion.fila = POSICION_INVALIDA;
    supertrajes[SEGUNDO_TRAJE].posicion.columna = POSICION_INVALIDA;
    supertrajes[SEGUNDO_TRAJE].recolectado = false;
    supertrajes[SEGUNDO_TRAJE].usado = false;
    supertrajes[SEGUNDO_TRAJE].cuadrante = CUADRANTE_2;

    int fila = (rand() % (9 - 0 + 1)) + 0;
    int columna = (rand() % (19 - 10 + 1)) + 10;
    while (!es_posicion_traje_correcta(personajes, tope_personajes, robots, tope_robots, columna, fila)) {
        fila = (rand() % (9 - 0 + 1)) + 0;
        columna = (rand() % (19 - 10 + 1)) + 10;
    }

    supertrajes[SEGUNDO_TRAJE].posicion.columna = columna;
    supertrajes[SEGUNDO_TRAJE].posicion.fila = fila;

    (*tope_supertraje)++;
}
/*/ PRE: 
    POST: Inicializa tercer traje en el tercer cuadrante.
/*/
void inicializar_traje_tercer_cuadrante(supertraje_t supertrajes[MAX_SUPERTRAJES], int* tope_supertraje, robot_t robots[MAX_ROBOTS], int tope_robots, personaje_t personajes[MAX_PERSONAJES], int tope_personajes)
{
    supertrajes[TERCER_TRAJE].posicion.fila = POSICION_INVALIDA;
    supertrajes[TERCER_TRAJE].posicion.columna = POSICION_INVALIDA;
    supertrajes[TERCER_TRAJE].recolectado = false;
    supertrajes[TERCER_TRAJE].usado = false;
    supertrajes[TERCER_TRAJE].cuadrante = CUADRANTE_3;

    int fila = (rand() % (19 - 10 + 1)) + 10;
    int columna = (rand() % (9 - 0 + 1)) + 0;
    while (!es_posicion_traje_correcta(personajes, tope_personajes, robots, tope_robots, columna, fila)) {
        fila = (rand() % (19 - 10 + 1)) + 10;
        columna = (rand() % (9 - 0 + 1)) + 0;
    }

    supertrajes[TERCER_TRAJE].posicion.columna = columna;
    supertrajes[TERCER_TRAJE].posicion.fila = fila;

    (*tope_supertraje)++;
}
/*/ PRE: 
    POST: Inicializa cuarto traje en el cuarto cuadrante.
/*/
void inicializar_traje_cuarto_cuadrante(supertraje_t supertrajes[MAX_SUPERTRAJES], int* tope_supertraje, robot_t robots[MAX_ROBOTS], int tope_robots, personaje_t personajes[MAX_PERSONAJES], int tope_personajes)
{
    supertrajes[CUARTO_TRAJE].posicion.fila = POSICION_INVALIDA;
    supertrajes[CUARTO_TRAJE].posicion.columna = POSICION_INVALIDA;
    supertrajes[CUARTO_TRAJE].recolectado = false;
    supertrajes[CUARTO_TRAJE].usado = false;
    supertrajes[CUARTO_TRAJE].cuadrante = CUADRANTE_4;

    int fila = (rand() % (19 - 10 + 1)) + 10;
    int columna = (rand() % (19 - 10 + 1)) + 10;
    while (!es_posicion_traje_correcta(personajes, tope_personajes, robots, tope_robots, columna, fila)) {
        fila = (rand() % (19 - 10 + 1)) + 10;
        columna = (rand() % (19 - 10 + 1)) + 10;
    }

    supertrajes[CUARTO_TRAJE].posicion.columna = columna;
    supertrajes[CUARTO_TRAJE].posicion.fila = fila;

    (*tope_supertraje)++;
}
/*/ PRE:
    POST: Inicializa todos los trajes en conjunto.
/*/
void inicializar_trajes(supertraje_t supertrajes[MAX_SUPERTRAJES], int* tope_supertraje, robot_t robots[MAX_ROBOTS], int tope_robots, personaje_t personajes[MAX_PERSONAJES], int tope_personajes)
{

    inicializar_traje_primer_cuadrante(supertrajes, tope_supertraje, robots, tope_robots, personajes, tope_personajes);

    inicializar_traje_segundo_cuadrante(supertrajes, tope_supertraje, robots, tope_robots, personajes, tope_personajes);

    inicializar_traje_tercer_cuadrante(supertrajes, tope_supertraje, robots, tope_robots, personajes, tope_personajes);

    inicializar_traje_cuarto_cuadrante(supertrajes, tope_supertraje, robots, tope_robots, personajes, tope_personajes);

    /* verificar_si_hay_superposicion_de_trajes(supertrajes, robots, personajes); */
}
/*/PRE: Personajes en posiciones validas, robots en posiciones validas, trajes en posiciones validas, tope_personajes/tope_robots/tope_supertrajes/tope_pinzas > 0.
   POST: Verifica si hay superposicion de alguna pinza con algun supertraje, personaj o robot.
/*/
bool verificar_posicion_pinza(coordenada_t pinzas[MAX_PINZAS], int tope_pinzas, personaje_t personajes[MAX_PERSONAJES], int tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots, supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertrajes, int fila, int columna)
{
    for (int i = 0; i < tope_pinzas; i++) {
        if (pinzas[i].columna == columna && pinzas[i].fila == fila) {
            return false;
        }
    }

    for (int i = 0; i < tope_personajes; i++) {
        if (personajes[i].posicion.columna == columna && personajes[i].posicion.fila == fila) {
            return false;
        }
    }

    for (int i = 0; i < tope_robots; i++) {
        if (robots[i].posicion.columna == columna && robots[i].posicion.fila == fila) {
            return false;
        }
    }

    for (int i = 0; i < tope_personajes; i++) {
        if (supertrajes[i].posicion.columna == columna && supertrajes[i].posicion.fila == fila) {
            return false;
        }
    }

    return true;
}

/*/ PRE:
    POST: Inicializa las pinzas del cuadrante 1.
/*/
void inicializar_pinzas_cuadrante_1(coordenada_t pinzas[MAX_PINZAS], int* tope_pinzas, personaje_t personajes[MAX_PERSONAJES], int tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots, supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertrajes)
{
    for (int i = 0; i < PINZAS_LIMITE_CUADRANTE_1; i++) {
        pinzas[i].fila = -1;
        pinzas[i].columna = -1;

        int fila = (rand() % (9 - 0 + 1)) + 0;
        int columna = (rand() % (9 - 0 + 1)) + 0;
        while (!verificar_posicion_pinza(pinzas, *tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes, fila, columna)) {
            fila = (rand() % (9 - 0 + 1)) + 0;
            columna = (rand() % (9 - 0 + 1)) + 0;
        }

        pinzas[i].fila = fila;
        pinzas[i].columna = columna;

        (*tope_pinzas)++;
    }
}
/*/ PRE:
    POST: Inicializa las pinzas del cuadrante 2.
/*/
void inicializar_pinzas_cuadrante_2(coordenada_t pinzas[MAX_PINZAS], int* tope_pinzas, personaje_t personajes[MAX_PERSONAJES], int tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots, supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertrajes)
{
    for (int i = PINZAS_LIMITE_CUADRANTE_1; i < PINZAS_LIMITE_CUADRANTE_2; i++) {
        pinzas[i].fila = -1;
        pinzas[i].columna = -1;
        int fila = (rand() % (9 - 0 + 1)) + 0;
        int columna = (rand() % (19 - 10 + 1)) + 10;
        while (!verificar_posicion_pinza(pinzas, *tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes, fila, columna)) {
            fila = (rand() % (9 - 0 + 1)) + 0;
            columna = (rand() % (19 - 10 + 1)) + 10;
        }

        pinzas[i].fila = fila;
        pinzas[i].columna = columna;

        (*tope_pinzas)++;
    }
}
/*/ PRE:
    POST: Inicializa las pinzas del cuadrante 3.
/*/
void inicializar_pinzas_cuadrante_3(coordenada_t pinzas[MAX_PINZAS], int* tope_pinzas, personaje_t personajes[MAX_PERSONAJES], int tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots, supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertrajes)
{
    for (int i = PINZAS_LIMITE_CUADRANTE_2; i < PINZAS_LIMITE_CUADRANTE_3; i++) {
        pinzas[i].fila = -1;
        pinzas[i].columna = -1;
        int fila = (rand() % (19 - 10 + 1)) + 10;
        int columna = (rand() % (9 - 0 + 1)) + 0;
        while (!verificar_posicion_pinza(pinzas, *tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes, fila, columna)) {
            fila = (rand() % (19 - 10 + 1)) + 10;
            columna = (rand() % (9 - 0 + 1)) + 0;
        }

        pinzas[i].fila = fila;
        pinzas[i].columna = columna;

        (*tope_pinzas)++;
    }
}
/*/ PRE:
    POST: Inicializa las pinzas del cuadrante 4.
/*/
void inicializar_pinzas_cuadrante_4(coordenada_t pinzas[MAX_PINZAS], int* tope_pinzas, personaje_t personajes[MAX_PERSONAJES], int tope_personajes, robot_t robots[MAX_ROBOTS], int tope_robots, supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertrajes)
{
    for (int i = PINZAS_LIMITE_CUADRANTE_3; i < PINZAS_LIMITE_CUADRANTE_4; i++) {
        pinzas[i].fila = -1;
        pinzas[i].columna = -1;
        int fila = (rand() % (19 - 10 + 1)) + 10;
        int columna = (rand() % (19 - 10 + 1)) + 10;
        while (!verificar_posicion_pinza(pinzas, *tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes, fila, columna)) {
            fila = (rand() % (19 - 10 + 1)) + 10;
            columna = (rand() % (19 - 10 + 1)) + 10;
        }

        pinzas[i].fila = fila;
        pinzas[i].columna = columna;

        (*tope_pinzas)++;
    }
}
/*/ PRE:
    POST: Inicializa las pinzas del cuadrante 1, 2, 3, y 4 en conjunto.
/*/
void inicializar_pinzas(coordenada_t pinzas[MAX_PINZAS], int* tope_pinzas, supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertrajes, robot_t robots[MAX_ROBOTS], int tope_robots, personaje_t personajes[MAX_PERSONAJES], int tope_personajes)
{
    *tope_pinzas = 0;
    inicializar_pinzas_cuadrante_1(pinzas, tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes);
    inicializar_pinzas_cuadrante_2(pinzas, tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes);
    inicializar_pinzas_cuadrante_3(pinzas, tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes);
    inicializar_pinzas_cuadrante_4(pinzas, tope_pinzas, personajes, tope_personajes, robots, tope_robots, supertrajes, tope_supertrajes);
}
/*/ PRE:
    POST: Se inicializan todos los elementos del juego y id_personaje_actual.
/*/
void inicializar_juego(juego_t* juego, bool contrasenia_completa)
{
    inicializar_robots(juego->robots, &(juego->tope_robots));
    inicializar_lasers(juego->robots, &juego->robots->tope_lasers, juego->tope_robots, contrasenia_completa);
    inicializar_personajes(juego->personajes, &(juego->tope_personajes), juego->robots, juego->tope_robots);
    inicializar_trajes(juego->supertrajes, &(juego->tope_supertraje), juego->robots, juego->tope_robots, juego->personajes, juego->tope_personajes);
    inicializar_pinzas(juego->pinzas, &(juego->tope_pinzas), juego->supertrajes, juego->tope_supertraje, juego->robots, juego->tope_robots, juego->personajes, juego->tope_personajes);
    juego->id_personaje_actual = 1;
}

int personajes_disponibles(char matriz[MAX_FILA][MAX_COLUMNA], personaje_t personajes[MAX_PERSONAJES], int id_personaje_actual)
{
    int inicio;
    if (id_personaje_actual == 2) {
        inicio = 1;
    } else if (id_personaje_actual == 3) {
        inicio = 2;
    } else if (id_personaje_actual == 4) {
        inicio = 3;
    } else {
        inicio = 0;
    }
    return inicio;
}
/*/ PRE:
        POST: Llena la matriz de espacios libres. (' ')
/*/
void rellenar_matriz_con_espacios(char matriz[MAX_FILA][MAX_COLUMNA])
{
    for (int i = 0; i < MAX_FILA; i++) {
        for (int j = 0; j < MAX_COLUMNA; j++) {
            matriz[i][j] = ESPACIO_LIBRE;
        }
    }
}
/*/ PRE: Tienen que estar dentro de los limites de la matriz.
    POST: Inserta los personajes en sus respectivas posiciones dentro de la matriz.
/*/
void ubicar_letras_de_personaje_en_matriz(char matriz[MAX_FILA][MAX_COLUMNA], personaje_t personajes[MAX_PERSONAJES], int tope_personajes, int id_personaje_actual)
{

    for (int i = personajes_disponibles(matriz, personajes, id_personaje_actual); i < tope_personajes; i++) {
        if (personajes[i].cuadrante_inicial == CUADRANTE_1) {
            matriz[personajes[i].posicion.fila][personajes[i].posicion.columna] = ELASTIC;
        } else if (personajes[i].cuadrante_inicial == CUADRANTE_2) {
            matriz[personajes[i].posicion.fila][personajes[i].posicion.columna] = VIOLETA;
        } else if (personajes[i].cuadrante_inicial == CUADRANTE_3) {
            matriz[personajes[i].posicion.fila][personajes[i].posicion.columna] = DASH;
        } else if (personajes[i].cuadrante_inicial == CUADRANTE_4) {
            matriz[personajes[i].posicion.fila][personajes[i].posicion.columna] = MR_INCREIBLE;
        }
    }
}
/*/ PRE: Tienen que estar dentro de los limites de la matriz.
    POST: Inserta los robots en sus respectivas posiciones dentro de la matriz.
/*/
void ubicar_letras_de_robots_en_matriz(char matriz[MAX_FILA][MAX_COLUMNA], robot_t robots[MAX_ROBOTS], int tope_robots)
{
    for (int i = 0; i < tope_robots; i++) {
        matriz[robots[i].posicion.fila][robots[i].posicion.columna] = ROBOT;
    }
}
/*/PRE: 
   POST: Devuelve true o false si el laser se encuentra dentro de la matriz.
/*/
bool esta_laser_dentro_matriz(coordenada_t laser)
{
    return laser.fila >= MIN_FILA && laser.fila < MAX_FILA && laser.columna >= MIN_COLUMNA && laser.columna < MAX_COLUMNA;
}
/*/ PRE: Tienen que estar dentro de los limites de la matriz.
    POST: Inserta los lasers en sus respectivas posiciones dentro de la matriz.
/*/
void ubicar_letras_de_lasers_en_matriz(char matriz[MAX_FILA][MAX_COLUMNA], robot_t robots[MAX_ROBOTS], int tope_robots)
{
    for (int i = 0; i < tope_robots; i++) {
        for (int j = 0; j < robots[i].tope_lasers; j++) {
            if (robots[i].lasers[j].fila != -1 && robots[i].lasers[j].columna != -1 && esta_laser_dentro_matriz(robots[i].lasers[j])) {
                matriz[robots[i].lasers[j].fila][robots[i].lasers[j].columna] = LASER;
            }
        }
    }
}
/*/ PRE: Tienen que estar dentro de los limites de la matriz.
    POST: Inserta los trajes en sus respectivas posiciones dentro de la matriz.
/*/
void ubicar_letras_de_trajes_en_matriz(char matriz[MAX_FILA][MAX_COLUMNA], supertraje_t supertrajes[MAX_SUPERTRAJES], int tope_supertraje, int id_personaje_actual)
{
    for (int i = 0; i < tope_supertraje; i++) {
        if (supertrajes[i].recolectado == false) {
            matriz[supertrajes[i].posicion.fila][supertrajes[i].posicion.columna] = SUPERTRAJE;
        }
    }
}
/*/ PRE: Tienen que estar dentro de los limites de la matriz.
    POST: Inserta las pinzas en sus respectivas posiciones dentro de la matriz.
/*/
void ubicar_letras_de_pinzas_en_matriz(char matriz[MAX_FILA][MAX_COLUMNA], coordenada_t pinzas[MAX_PINZAS], int tope_pinzas)
{
    for (int i = 0; i < tope_pinzas; i++) {
        matriz[pinzas[i].fila][pinzas[i].columna] = PINZA;
    }
}

/*/ PRE: Personaje y traje que estar en posicion valida.
    POST: Campo tiene_supertraje de personajes y campo recolectado de supertrajes cambia a true si la posicion del personaje
    en uso es la misma que la de un supertraje (si es que es el supertraje que les corresponde).
/*/
void recolectar_traje(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES], int id_personaje_actual)
{
    if (personajes[id_personaje_actual - 1].posicion.fila == supertrajes[id_personaje_actual - 1].posicion.fila && personajes[id_personaje_actual - 1].posicion.columna == supertrajes[id_personaje_actual - 1].posicion.columna && !supertrajes[id_personaje_actual - 1].recolectado) {
        supertrajes[id_personaje_actual - 1].recolectado = true;
        personajes[id_personaje_actual - 1].tiene_supertraje = true;
        printf("TRAJE RECOLECTADO! PARA ACTIVAR EL PODER PULSA LA TECLA F");
    } else if (personajes[id_personaje_actual - 1].posicion.fila == supertrajes[ID_ELASTIC].posicion.fila && personajes[id_personaje_actual - 1].posicion.columna == supertrajes[ID_ELASTIC].posicion.columna && !supertrajes[ID_ELASTIC].recolectado) {
        printf("ESTAS TRATANDO DE AGARRAR EL SUPERTRAJE DE ELASTIC! AGARRA EL TUYO!");
    } else if (personajes[id_personaje_actual - 1].posicion.fila == supertrajes[ID_VIOLETA].posicion.fila && personajes[id_personaje_actual - 1].posicion.columna == supertrajes[ID_VIOLETA].posicion.columna && !supertrajes[ID_VIOLETA].recolectado) {
        printf("ESTAS TRATANDO DE AGARRAR EL SUPERTRAJE DE VIOLETA! AGARRA EL TUYO!");
    } else if (personajes[id_personaje_actual - 1].posicion.fila == supertrajes[ID_DASH].posicion.fila && personajes[id_personaje_actual - 1].posicion.columna == supertrajes[ID_DASH].posicion.columna && !supertrajes[ID_DASH].recolectado) {
        printf("ESTAS TRATANDO DE AGARRAR EL SUPERTRAJE DE DASH! AGARRA EL TUYO!");
    } else if (personajes[id_personaje_actual - 1].posicion.fila == supertrajes[ID_MR_INCREIBLE].posicion.fila && personajes[id_personaje_actual - 1].posicion.columna == supertrajes[ID_MR_INCREIBLE].posicion.columna && !supertrajes[ID_MR_INCREIBLE].recolectado) {
        printf("ESTAS TRATANDO DE AGARRAR EL SUPERTRAJE DE MR INCREIBLE! AGARRA EL TUYO!");
    }
}
/*/ PRE: El indice tiene que ser menor al tope de los robots, robots y personajes tienen que estar en una posicion valida.
    POST: Genera una posicion aleatoria para el personaje en uso alrededor del robot de su cuadrante y comprueba que esta posicion no sea la misma
    que la del mismo robot.
/*/
void posicion_random_alrededor_del_robot(personaje_t personajes[MAX_PERSONAJES], robot_t robots[MAX_ROBOTS], int indice)
{
    int upper_columna = robots[indice].posicion.columna + 1;
    int lower_columna = robots[indice].posicion.columna - 1;
    int upper_fila = robots[indice].posicion.fila + 1;
    int lower_fila = robots[indice].posicion.fila - 1;
    personajes[indice].posicion.fila = (rand() % (upper_fila - lower_fila + 1)) + lower_fila;
    personajes[indice].posicion.columna = (rand() % (upper_columna - lower_columna + 1)) + lower_columna;
    while ((personajes[indice].posicion.fila == robots[indice].posicion.fila && personajes[indice].posicion.columna == robots[indice].posicion.columna) || (personajes[indice].posicion.fila > MAX_FILA) || (personajes[indice].posicion.fila < MIN_FILA)
        || (personajes[indice].posicion.columna > MAX_COLUMNA) || personajes[indice].posicion.fila < MIN_COLUMNA) {

        personajes[indice].posicion.fila = (rand() % (upper_fila - lower_fila + 1)) + lower_fila;
        personajes[indice].posicion.columna = (rand() % (upper_columna - lower_columna + 1)) + lower_columna;
    }
}
/*/ PRE: id_personaje_actual < tope_personajes y id_personaje_actual >= 0, personajes y robots en posiciones validas.
    POST: Si el personaje en uso tiene la misma posicion que una pinza, se lo lleva a una posicion aleatoria alrededor
    de un robot del mismo cuadrante donde el personaje en uso se intercambio. Se imprime informacion.
/*/
void pisar_pinza(personaje_t personajes[MAX_PERSONAJES], robot_t robots[MAX_ROBOTS], coordenada_t pinzas[MAX_PINZAS], int id_personaje_actual, int tope_pinzas)
{
    for (int i = 0; i < tope_pinzas; i++) {
        if (id_personaje_actual - 1 == ID_ELASTIC && personajes[id_personaje_actual - 1].posicion.fila == pinzas[i].fila && personajes[id_personaje_actual - 1].posicion.columna == pinzas[i].columna) {
            posicion_random_alrededor_del_robot(personajes, robots, ID_ELASTIC);
            printf("【PISASTE UNA PINZA!】");
        } else if (id_personaje_actual - 1 == ID_VIOLETA && personajes[id_personaje_actual - 1].posicion.fila == pinzas[i].fila && personajes[id_personaje_actual - 1].posicion.columna == pinzas[i].columna) {
            posicion_random_alrededor_del_robot(personajes, robots, ID_VIOLETA);
            printf("【PISASTE UNA PINZA!】");
        } else if (id_personaje_actual - 1 == ID_DASH && personajes[id_personaje_actual - 1].posicion.fila == pinzas[i].fila && personajes[id_personaje_actual - 1].posicion.columna == pinzas[i].columna) {
            posicion_random_alrededor_del_robot(personajes, robots, ID_DASH);
            printf("【PISASTE UNA PINZA!】");
        } else if (id_personaje_actual - 1 == ID_MR_INCREIBLE && !personajes[ID_MR_INCREIBLE].poder_activado && personajes[id_personaje_actual - 1].posicion.fila == pinzas[i].fila && personajes[id_personaje_actual - 1].posicion.columna == pinzas[i].columna) {
            posicion_random_alrededor_del_robot(personajes, robots, ID_MR_INCREIBLE);
            printf("【PISASTE UNA PINZA!】");
        }
    }
}

/*/ PRE: 
    POST: Activa el traje de elastic girl y muestra un mensaje de activacion como notificacion.
/*/
void activar_traje_elastic(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES])
{
    personajes[ID_ELASTIC].poder_activado = true;
    supertrajes[ID_ELASTIC].usado = true;
    printf("SUPERTRAJE DE ELASTIC GIRL ACTIVO! SALTO TRIPLE HABILITADO POR 5 MOVIMIENTOS!");
}
/*/ PRE: 
    POST: Activa el traje de dash y muestra un mensaje de activacion como notificacion.
/*/
void activar_traje_dash(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES])
{
    personajes[ID_DASH].poder_activado = true;
    supertrajes[ID_DASH].usado = true;
    if (personajes[ID_DASH].poder_activado && personajes[ID_DASH].movimientos_con_poder > 4) {
        personajes[ID_DASH].posicion.fila = (rand() % (19 - 10 + 1)) + 10;
        personajes[ID_DASH].posicion.columna = (rand() % (19 - 10 + 1)) + 10;
        printf("TRAJE DE DASH ACTIVADO! APARECISTE EN EL CUADRANTE DE MR.INCREIBLE!");
        personajes[ID_DASH].poder_activado = false;
    }
}
/*/ PRE: 
    POST: Activa el traje de mr increible y muestra un mensaje de activacion como notificacion.
/*/
void activar_traje_mr_increible(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES])
{
    personajes[ID_MR_INCREIBLE].poder_activado = true;
    supertrajes[ID_MR_INCREIBLE].usado = true;
    printf("PODER DE MR INCREIBLE ACTIVADO! LAS PINZAS NO TIENEN EFECTO EN VOS DURANTE 5 MOVIMIENTOS!");
}
/*/ PRE: 
    POST: Activa el traje de violeta y muestra un mensaje de activacion como notificacion.
/*/
void activar_traje_violeta(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES])
{
    personajes[ID_VIOLETA].poder_activado = true;
    supertrajes[ID_VIOLETA].usado = true;
    printf("PODER DE VIOLETA ACTIVADO! LOS LASERS NO TIENEN EFECTO DURANTE 5 MOVIMIENTOS!");
}

/*/PRE:
   POST: Desactiva el traje de elastic girl. 
/*/
void desactivar_traje_elastic(personaje_t personajes[MAX_PERSONAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 != ID_ELASTIC && personajes[ID_ELASTIC].poder_activado && personajes[ID_ELASTIC].movimientos_con_poder > 0) {
        personajes[ID_ELASTIC].poder_activado = false;
        printf("PODER DE ELASTIC DESACTIVADO!");
    }
}
/*/PRE:
   POST: Desactiva el traje de mr increible. 
/*/
void desactivar_traje_mr_increible(personaje_t personajes[MAX_PERSONAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_MR_INCREIBLE && personajes[ID_MR_INCREIBLE].movimientos_con_poder < 1) {
        personajes[ID_MR_INCREIBLE].poder_activado = false;
        printf("PODER DE MR INCREIBLE DESACTIVADO!");
    }
}
/*/PRE:
   POST: Desactiva el traje de violeta. 
/*/
void desactivar_traje_violeta(personaje_t personajes[MAX_PERSONAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_VIOLETA && personajes[ID_VIOLETA].movimientos_con_poder < 1) {
        personajes[ID_VIOLETA].poder_activado = false;
        printf("PODER DE VIOLETA DESACTIVADO!");
    }
}
/*/PRE:
   POST: Solo hace una impresion de la division de los cuadrantes donde los elementos spawnean.
/*/
void imprimir_division_de_cuadrantes(char matriz[MAX_FILA][MAX_COLUMNA])
{
    for (int i = 0; i < MAX_FILA; i++) {
        for (int j = 0; j + 1 < MAX_COLUMNA; j++) {
            printf("%c", matriz[i][j]);
            if (j + 1 == MAX_COLUMNA / 2) {
                printf(" | ");
            }
        }
        printf("%c\n", matriz[i][MAX_COLUMNA - 1]);
        if (i + 1 == MAX_FILA / 2) {
            for (int j = 0; j < MAX_COLUMNA; j++) {
                if (j == MAX_COLUMNA / 2) {
                    printf(" + ");

                } else {
                    printf("-");
                }
            }
            printf("-\n");
        }
    }
}
/*/PRE: La matriz tiene que ser 20x20 (FILA = 20, COLUMNA = 20)
   POST: Imprime una 'X' como puerta de salida en la matriz. 
/*/
void imprimir_puerta_de_salida(char matriz[MAX_FILA][MAX_COLUMNA], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_MR_INCREIBLE) {
        matriz[0][19] = 'X';
    }
}
/*/PRE:
   POST: Imprime todos los elementos en el terreno de juego.
/*/
void imprimir_terreno(juego_t juego)
{
    char matriz[MAX_FILA][MAX_COLUMNA];
    system("clear");
    printf("\n");
    rellenar_matriz_con_espacios(matriz);
    ubicar_letras_de_pinzas_en_matriz(matriz, juego.pinzas, juego.tope_pinzas);
    ubicar_letras_de_trajes_en_matriz(matriz, juego.supertrajes, juego.tope_supertraje, juego.id_personaje_actual);
    ubicar_letras_de_personaje_en_matriz(matriz, juego.personajes, juego.tope_personajes, juego.id_personaje_actual);
    ubicar_letras_de_robots_en_matriz(matriz, juego.robots, juego.tope_robots);
    ubicar_letras_de_lasers_en_matriz(matriz, juego.robots, juego.tope_robots);
    imprimir_puerta_de_salida(matriz, juego.id_personaje_actual);
    imprimir_division_de_cuadrantes(matriz);
}
/*/PRE: movimientos > 0 && movimientos_con_poder > 0 && id_personaje_actual > 0
   POST: Resta movimientos normales y tambien los movimientos_con_poder simultaneamente si es que el poder del personaje en uso esta activado 
/*/
void restar_movimientos(personaje_t personajes[MAX_PERSONAJES], int* movimientos, int id_personaje_actual)
{
    (*movimientos)--;
    if (id_personaje_actual - 1 == ID_ELASTIC && personajes[ID_ELASTIC].poder_activado && personajes[ID_ELASTIC].movimientos_con_poder > 0) {
        personajes[ID_ELASTIC].movimientos_con_poder--;
    }
    if (id_personaje_actual - 1 == ID_MR_INCREIBLE && personajes[ID_MR_INCREIBLE].poder_activado && personajes[ID_MR_INCREIBLE].movimientos_con_poder > 0) {
        personajes[ID_MR_INCREIBLE].movimientos_con_poder--;
    }
    if (id_personaje_actual - 1 == ID_VIOLETA && personajes[ID_VIOLETA].poder_activado && personajes[ID_VIOLETA].movimientos_con_poder > 0) {
        personajes[ID_VIOLETA].movimientos_con_poder--;
    }
    if (id_personaje_actual - 1 == ID_DASH && personajes[ID_DASH].poder_activado && personajes[ID_MR_INCREIBLE].movimientos_con_poder > 4) {
        personajes[ID_DASH].movimientos_con_poder--;
    }
}
/*/PRE: id_personaje_actual > 0.
   POST: Imprime por pantalla cada vez que intercambiamos de personaje. 
/*/
void imprimir_intercambio_de_pj(personaje_t personajes[MAX_PERSONAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_ELASTIC) {
        printf("SOS ELASTIC GIRL!");
    } else if (id_personaje_actual - 1 == ID_VIOLETA) {
        printf("BIEN! AHORA SOS VIOLETA! BUSCA A DASH!");
    } else if (id_personaje_actual - 1 == ID_DASH) {
        printf("GENIAL! AHORA SOS DASH! BUSCA A MR INCREIBLE!");
    } else if (id_personaje_actual - 1 == ID_MR_INCREIBLE) {
        printf("BIEN! SOS MR INCREIBLE! AHORA ESCAPA POR LA PUERTA!");
    }
}
/*/PRE: movimiento = A or W or S or D | tope_robots > 0 | cantidad_movimientos > 0 | id_personaje_actual > 0 
   POST: Mueve a la derecha el personaje en uso, intercambia personaje en caso de interactuar con un personaje valido, no intercambia en caso de interactuar con personaje invalido, 
   no deja que el personaje escape por la parte derecha del mapa, mueve el laser cada vez que el movimiento es valido.
/*/
void movimiento_derecha(personaje_t personajes[MAX_PERSONAJES], int* id_personaje_actual, int cantidad_movimientos, char movimiento, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    if (movimiento == DERECHA) {
        if (personajes[*id_personaje_actual - 1].posicion.columna + cantidad_movimientos == personajes[*id_personaje_actual].posicion.columna && personajes[*id_personaje_actual - 1].posicion.fila == personajes[*id_personaje_actual].posicion.fila) {
            (*id_personaje_actual)++;
            imprimir_intercambio_de_pj(personajes, *id_personaje_actual);
        } else if (personajes[ID_ELASTIC].posicion.columna + cantidad_movimientos == personajes[ID_DASH].posicion.columna && personajes[ID_ELASTIC].posicion.fila == personajes[ID_DASH].posicion.fila) {
            printf("No podes agarrar a Dash todavia, antes de eso tenes que buscar a VIOLETA!");
        } else if (personajes[ID_ELASTIC].posicion.columna + cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_ELASTIC].posicion.fila == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, primero tenes que salvar a VIOLETA y DASH!");
        } else if (personajes[ID_VIOLETA].posicion.columna + cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_VIOLETA].posicion.fila == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, antes de eso tenes que buscar a DASH!");
        } else {
            if (personajes[*id_personaje_actual - 1].posicion.columna + cantidad_movimientos >= MAX_COLUMNA) {
                printf("NO PODES SALIR FUERA DE LA ZONA DE JUEGO!.");
                personajes[*id_personaje_actual - 1].posicion.columna = MAX_COLUMNA - 1;
            } else {
                personajes[*id_personaje_actual - 1].posicion.columna += cantidad_movimientos;
                restar_movimientos(personajes, &personajes[*id_personaje_actual - 1].movimientos, *id_personaje_actual);
                mover_lasers(robots, tope_robots);
            }
        }
    }
}
/*/PRE: movimiento = A or W or S or D | tope_robots > 0 | cantidad_movimientos > 0 | id_personaje_actual > 0 
   POST: Mueve a la izquierda el personaje en uso, intercambia personaje en caso de interactuar con un personaje valido, no intercambia en caso de interactuar con personaje invalido, 
   no deja que el personaje escape por la parte derecha del mapa, mueve el laser cada vez que el movimiento es valido.
/*/
void movimiento_izquierda(personaje_t personajes[MAX_PERSONAJES], int* id_personaje_actual, int cantidad_movimientos, char movimiento, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    if (movimiento == IZQUIERDA) {
        if (personajes[*id_personaje_actual - 1].posicion.columna - cantidad_movimientos == personajes[*id_personaje_actual].posicion.columna && personajes[*id_personaje_actual - 1].posicion.fila == personajes[*id_personaje_actual].posicion.fila) {
            (*id_personaje_actual)++;
            imprimir_intercambio_de_pj(personajes, *id_personaje_actual);
        } else if (personajes[ID_ELASTIC].posicion.columna - cantidad_movimientos == personajes[ID_DASH].posicion.columna && personajes[ID_ELASTIC].posicion.fila == personajes[ID_DASH].posicion.fila) {
            printf("No podes agarrar a Dash todavia, antes de eso tenes que buscar a VIOLETA!");
        } else if (personajes[ID_ELASTIC].posicion.columna - cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_ELASTIC].posicion.fila == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, primero tenes que salvar a VIOLETA y DASH!");
        } else if (personajes[ID_VIOLETA].posicion.columna - cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_VIOLETA].posicion.fila == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, antes de eso tenes que buscar a DASH!");
        } else {
            if (personajes[*id_personaje_actual - 1].posicion.columna - cantidad_movimientos <= MIN_COLUMNA - 1) {
                printf("NO PODES SALIR FUERA DE LA ZONA DE JUEGO!");
                personajes[*id_personaje_actual - 1].posicion.columna = MIN_COLUMNA;
            } else {
                personajes[*id_personaje_actual - 1].posicion.columna -= cantidad_movimientos;
                restar_movimientos(personajes, &personajes[*id_personaje_actual - 1].movimientos, *id_personaje_actual);
                mover_lasers(robots, tope_robots);
            }
        }
    }
}
/*/PRE: movimiento = A or W or S or D | tope_robots > 0 | cantidad_movimientos > 0 | id_personaje_actual > 0 
   POST: Mueve a la arriba el personaje en uso, intercambia personaje en caso de interactuar con un personaje valido, no intercambia en caso de interactuar con personaje invalido, 
   no deja que el personaje escape por la parte derecha del mapa, mueve el laser cada vez que el movimiento es valido.
/*/
void movimiento_arriba(personaje_t personajes[MAX_PERSONAJES], int* id_personaje_actual, int cantidad_movimientos, char movimiento, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    if (movimiento == ARRIBA) {
        if (personajes[*id_personaje_actual - 1].posicion.columna == personajes[*id_personaje_actual].posicion.columna && personajes[*id_personaje_actual - 1].posicion.fila - cantidad_movimientos == personajes[*id_personaje_actual].posicion.fila) {
            (*id_personaje_actual)++;
            imprimir_intercambio_de_pj(personajes, *id_personaje_actual);
        } else if (personajes[ID_ELASTIC].posicion.columna == personajes[ID_DASH].posicion.columna && personajes[ID_ELASTIC].posicion.fila - cantidad_movimientos == personajes[ID_DASH].posicion.fila) {
            printf("No podes agarrar a Dash todavia, antes de eso tenes que buscar a VIOLETA!");
        } else if (personajes[ID_ELASTIC].posicion.columna == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_ELASTIC].posicion.fila - cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, primero tenes que salvar a VIOLETA y DASH!");
        } else if (personajes[ID_VIOLETA].posicion.columna == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_VIOLETA].posicion.fila - cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, antes de eso tenes que buscar a DASH!");
        } else {
            if (personajes[*id_personaje_actual - 1].posicion.fila - cantidad_movimientos <= MIN_FILA - 1) {
                printf("NO PODES SALIR FUERA DE LA ZONA DE JUEGO!");
                personajes[*id_personaje_actual - 1].posicion.fila = MIN_FILA;
            } else {
                personajes[*id_personaje_actual - 1].posicion.fila -= cantidad_movimientos;
                restar_movimientos(personajes, &personajes[*id_personaje_actual - 1].movimientos, *id_personaje_actual);
                mover_lasers(robots, tope_robots);
            }
        }
    }
}
/*/PRE: movimiento = A or W or S or D | tope_robots > 0 | cantidad_movimientos > 0 | id_personaje_actual > 0 
   POST: Mueve a la abajo el personaje en uso, intercambia personaje en caso de interactuar con un personaje valido, no intercambia en caso de interactuar con personaje invalido, 
   no deja que el personaje escape por la parte derecha del mapa, mueve el laser cada vez que el movimiento es valido.
/*/
void movimiento_abajo(personaje_t personajes[MAX_PERSONAJES], int* id_personaje_actual, int cantidad_movimientos, char movimiento, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    if (movimiento == ABAJO) {
        if (personajes[*id_personaje_actual - 1].posicion.columna == personajes[*id_personaje_actual].posicion.columna && personajes[*id_personaje_actual - 1].posicion.fila + cantidad_movimientos == personajes[*id_personaje_actual].posicion.fila) {
            (*id_personaje_actual)++;
            imprimir_intercambio_de_pj(personajes, *id_personaje_actual);
        } else if (personajes[ID_ELASTIC].posicion.columna == personajes[ID_DASH].posicion.columna && personajes[ID_ELASTIC].posicion.fila + cantidad_movimientos == personajes[ID_DASH].posicion.fila) {
            printf("No podes agarrar a Dash todavia, antes de eso tenes que buscar a VIOLETA!");
        } else if (personajes[ID_ELASTIC].posicion.columna == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_ELASTIC].posicion.fila + cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, primero tenes que salvar a VIOLETA y DASH!");
        } else if (personajes[ID_VIOLETA].posicion.columna == personajes[ID_MR_INCREIBLE].posicion.columna && personajes[ID_VIOLETA].posicion.fila + cantidad_movimientos == personajes[ID_MR_INCREIBLE].posicion.fila) {
            printf("No podes agarrar a MR.INCREIBLE todavia, antes de eso tenes que buscar a DASH!");
        } else {
            if (personajes[*id_personaje_actual - 1].posicion.fila + cantidad_movimientos >= MAX_FILA) {
                printf("NO PODES SALIR FUERA DE LA ZONA DE JUEGO!");
                personajes[*id_personaje_actual - 1].posicion.fila = MAX_FILA - 1;
            } else {
                personajes[*id_personaje_actual - 1].posicion.fila += cantidad_movimientos;
                restar_movimientos(personajes, &personajes[*id_personaje_actual - 1].movimientos, *id_personaje_actual);
                mover_lasers(robots, tope_robots);
            }
        }
    }
}
/*/PRE: 
   POST: Mueve el personaje en uso y hace todo lo mencionado anteriormente en las ultimas 4 funciones.
/*/
void mover_personaje(personaje_t personajes[MAX_PERSONAJES], int* id_personaje_actual, int cantidad_movimientos, char movimiento, robot_t robots[MAX_ROBOTS], int tope_robots)
{
    movimiento_derecha(personajes, id_personaje_actual, cantidad_movimientos, movimiento, robots, tope_robots);
    movimiento_izquierda(personajes, id_personaje_actual, cantidad_movimientos, movimiento, robots, tope_robots);
    movimiento_arriba(personajes, id_personaje_actual, cantidad_movimientos, movimiento, robots, tope_robots);
    movimiento_abajo(personajes, id_personaje_actual, cantidad_movimientos, movimiento, robots, tope_robots);
}
/*/PRE: id_personaje_actual > 0 
   POST: Hace un chequeo de estado de todo lo relacionado a los superpoderes del personaje elastic
/*/
void chequear_estado_traje_elastic(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_ELASTIC && personajes[ID_ELASTIC].tiene_supertraje && !personajes[ID_ELASTIC].poder_activado) {
        activar_traje_elastic(personajes, supertrajes);
    } else if (id_personaje_actual - 1 == ID_ELASTIC && personajes[ID_ELASTIC].tiene_supertraje && personajes[ID_ELASTIC].poder_activado) {
        printf("YA ACTIVASTE EL PODER DE ELASTIC GIRL ANTES!");
    } else if (id_personaje_actual - 1 == ID_ELASTIC && !personajes[ID_ELASTIC].tiene_supertraje) {
        printf("TODAVIA NO AGARRASTE TU SUPERTRAJE! BUSCALO!");
    }
}
/*/PRE: id_personaje_actual > 0 
   POST: Hace un chequeo de estado de todo lo relacionado a los superpoderes del personaje dash
/*/
void chequear_estado_traje_dash(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_DASH && personajes[ID_DASH].tiene_supertraje && !personajes[ID_DASH].poder_activado) {
        activar_traje_dash(personajes, supertrajes);
    } else if (id_personaje_actual - 1 == ID_DASH && personajes[ID_DASH].tiene_supertraje && personajes[ID_DASH].poder_activado) {
        printf("YA ACTIVASTE EL PODER DE DASH ANTES! SOLO LO PODES USAR 1 VEZ!");
    } else if (id_personaje_actual - 1 == ID_DASH && !personajes[ID_DASH].tiene_supertraje) {
        printf("TODAVIA NO AGARRASTE EL SUPERTRAJE! ANDA A BUSCARLO!");
    }
}
/*/PRE: id_personaje_actual > 0 
   POST: Hace un chequeo de estado de todo lo relacionado a los superpoderes del personaje mr increible
/*/
void chequear_estado_traje_mr_increible(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_MR_INCREIBLE && personajes[ID_MR_INCREIBLE].tiene_supertraje && !personajes[ID_MR_INCREIBLE].poder_activado) {
        activar_traje_mr_increible(personajes, supertrajes);
    } else if (id_personaje_actual - 1 == ID_MR_INCREIBLE && personajes[ID_MR_INCREIBLE].tiene_supertraje && personajes[ID_MR_INCREIBLE].poder_activado) {
        printf("YA ACTIVASTE EL PODER DE MR INCREIBLE ANTES!");
    } else if (id_personaje_actual - 1 == ID_MR_INCREIBLE && !personajes[ID_MR_INCREIBLE].tiene_supertraje) {
        printf("TODAVIA NO AGARRASTE EL SUPERTRAJE! ANDA A BUSCARLO!");
    }
}
/*/PRE: id_personaje_actual > 0 
   POST: Hace un chequeo de estado de todo lo relacionado a los superpoderes del personaje violeta
/*/
void chequear_estado_traje_violeta(personaje_t personajes[MAX_PERSONAJES], supertraje_t supertrajes[MAX_SUPERTRAJES], int id_personaje_actual)
{
    if (id_personaje_actual - 1 == ID_VIOLETA && personajes[ID_VIOLETA].tiene_supertraje && !personajes[ID_VIOLETA].poder_activado) {
        activar_traje_violeta(personajes, supertrajes);
    } else if (id_personaje_actual - 1 == ID_VIOLETA && personajes[ID_VIOLETA].tiene_supertraje && personajes[ID_VIOLETA].poder_activado) {
        printf("YA ACTIVASTE EL PODER DE VIOLETA ANTES!");
    } else if (id_personaje_actual - 1 == ID_VIOLETA && !personajes[ID_VIOLETA].tiene_supertraje) {
        printf("TODAVIA NO AGARRASTE EL SUPERTRAJE! ANDA A BUSCARLO!");
    }
}
/*/PRE: movimiento tiene que ser A, W, S, D o F 
   POST: Hace todas las jugadas e interacciones de la partida.
/*/
void realizar_jugada(juego_t* juego, char movimiento)
{
    if (movimiento == ACTIVAR_SUPERTRAJE) {
        chequear_estado_traje_elastic(juego->personajes, juego->supertrajes, juego->id_personaje_actual);
        chequear_estado_traje_violeta(juego->personajes, juego->supertrajes, juego->id_personaje_actual);
        chequear_estado_traje_dash(juego->personajes, juego->supertrajes, juego->id_personaje_actual);
        chequear_estado_traje_mr_increible(juego->personajes, juego->supertrajes, juego->id_personaje_actual);
    }
    desactivar_traje_elastic(juego->personajes, juego->id_personaje_actual);
    desactivar_traje_violeta(juego->personajes, juego->id_personaje_actual);
    desactivar_traje_mr_increible(juego->personajes, juego->id_personaje_actual);

    if (juego->personajes[ID_ELASTIC].poder_activado && juego->personajes[ID_ELASTIC].movimientos_con_poder > 0) {
        mover_personaje(juego->personajes, &juego->id_personaje_actual, 3, movimiento, juego->robots, juego->tope_robots);
    } else {
        mover_personaje(juego->personajes, &juego->id_personaje_actual, 1, movimiento, juego->robots, juego->tope_robots);

    }
    
    recolectar_traje(juego->personajes, juego->supertrajes, juego->id_personaje_actual);
    pisar_pinza(juego->personajes, juego->robots, juego->pinzas, juego->id_personaje_actual, juego->tope_pinzas);
}

/*/PRE:
   POST: Devuelve si se pierde, gana o sigue la partida.
/*/
int estado_juego(juego_t juego)
{
    for (int i = 0; i < juego.tope_robots; i++) {
        if (juego.personajes[juego.id_personaje_actual - 1].posicion.columna == juego.robots[i].posicion.columna && juego.personajes[juego.id_personaje_actual - 1].posicion.fila == juego.robots[i].posicion.fila) {
            return PERDISTE;
        }
    }
    for (int i = 0; i < juego.tope_robots; i++) {
        for (int j = 0; j < juego.robots[i].tope_lasers; j++) {
            /* if personaje es violeta y superpoder activado return 0 */
            if (juego.id_personaje_actual - 1 == ID_VIOLETA && juego.personajes[ID_VIOLETA].poder_activado && juego.personajes[ID_VIOLETA].posicion.columna == juego.robots[i].lasers[j].columna && juego.personajes[ID_VIOLETA].posicion.fila == juego.robots[i].lasers[j].fila) {
                return EN_CURSO;
            } else if (juego.personajes[juego.id_personaje_actual - 1].posicion.columna == juego.robots[i].lasers[j].columna && juego.personajes[juego.id_personaje_actual - 1].posicion.fila == juego.robots[i].lasers[j].fila) {
                return PERDISTE;
            }
        }
    }
    if (juego.personajes[juego.id_personaje_actual - 1].movimientos < 1) {
        return PERDISTE;
    } else if (juego.personajes[ID_MR_INCREIBLE].posicion.fila == 0 && juego.personajes[ID_MR_INCREIBLE].posicion.columna == 19) {
        return GANASTE;
    } else {
        return EN_CURSO;
    }
}
