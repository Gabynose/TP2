#ifndef __KRONOS_H__
#define __KRONOS_H__
#include <stdbool.h>

#define MAX_LASERS 100
#define MAX_ROBOTS 10
#define MAX_PERSONAJES 10
#define MAX_PINZAS 100
#define MAX_SUPERTRAJES 10



typedef struct coordenada{
	int fila;
	int columna;
} coordenada_t; 

typedef struct robot{
	coordenada_t posicion;
	coordenada_t lasers[MAX_LASERS];
	int tope_lasers;

} robot_t;

typedef struct supertraje{
	coordenada_t posicion;
	int cuadrante;
	bool recolectado;
	bool usado;
} supertraje_t;

typedef struct personaje{
	bool poder_activado;
	bool tiene_supertraje;
	coordenada_t posicion;
	int movimientos;
	int movimientos_con_poder;
	int cuadrante_inicial;
} personaje_t;

typedef struct juego{
	personaje_t personajes [MAX_PERSONAJES];
	int tope_personajes;
	robot_t robots [MAX_ROBOTS];
	int tope_robots;
	coordenada_t pinzas [MAX_PINZAS];
	int tope_pinzas;
	supertraje_t supertrajes [MAX_SUPERTRAJES];
	int tope_supertraje;
	int longitud_laser;
	int id_personaje_actual;
} juego_t;

/* Inicializa el juego, cargando toda la informacion inicial de los robots,
los supertrajes, el personaje, los lasers y las pinzas.
EL campo id_personaje_actual comienza en 1.
*/
void inicializar_juego (juego_t* juego, bool contrasenia_completa);

/* Movera el personaje y se realizaran todas las acciones necesarias en caso
de chocar con algun elemento.
*/
void realizar_jugada(juego_t* juego, char movimiento);

/* Imprime el juego por pantalla
*/
void imprimir_terreno (juego_t juego);

/*EL juego se dara por ganado si se esta sobre el casillero de salida siendo el
personaje Mr. Increible y perdido si el personaje (cualquiera) se queda sin movimivientos.
Devuelve:
-> 1 si se gano el juego
-> 0 si el juego aun se esta jugando
-> -1 si se perdio el juego.
*/
int estado_juego(juego_t juego);

#endif /* __KRONOS_H__ */