#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include "kronos.h"
#include "increidle.h"
#include <unistd.h>
#include <string.h>
const char ARRIBA = 'W';
const char ABAJO = 'S';
const char IZQUIERDA = 'A';
const char DERECHA = 'D';
const char ACTIVAR_SUPERTRAJE = 'F';

/*/PRE: 
   POST: Pido un movimiento (letra) y me pide reingresar si ingreso un movimiento invalido
/*/
void pedir_movimiento(char* movimiento_ingresado)
{
	printf("Ingrese su proximo movimiento, recuerde que solo puede moverse con las teclas W (arriba), A (abajo), S (izquierda), D (derecha):\n");
	scanf(" %c", movimiento_ingresado);
	while (*movimiento_ingresado != ARRIBA && *movimiento_ingresado != ABAJO && *movimiento_ingresado != IZQUIERDA && *movimiento_ingresado != DERECHA && *movimiento_ingresado != ACTIVAR_SUPERTRAJE){
		printf("Tecla de movimiento invalida! SOLO puede moverse con las teclas W (arriba), A (abajo), S (izquierda), D (derecha)\n");
		printf("Ingrese su proximo movimiento:\n");
		scanf(" %c", movimiento_ingresado);
	}
}
/*/PRE: 
   POST: Imprimo los movimientos que me quedan.
/*/
void imprimir_movimientos_restantes(juego_t juego)
{
	if (juego.personajes[juego.id_personaje_actual - 1].movimientos <= 0)
	{
		printf("✴YA NO TENES MOVIMIENTOS✴\n");
	}
	else if (juego.personajes[juego.id_personaje_actual - 1].movimientos == 1)
	{
		printf("CUIDADO!!! TE QUEDA 『%i』 MOVIMIENTO! USALO BIEN!\n", juego.personajes[juego.id_personaje_actual - 1].movimientos);
		
	} else
	{
		printf("TE QUEDAN 『%i』 MOVIMIENTOS!\n", juego.personajes[juego.id_personaje_actual - 1].movimientos);
	}
}
/*/PRE: 
   POST: Imprime si gano o pierdo.
/*/
void imprimir_estado_del_juego(juego_t juego){
	if (estado_juego(juego) == -1)
	{
		printf("     【PERDISTE】     \n");
		
	} else if (estado_juego(juego) == 1)
	{
		printf("LOGRASTE ESCAPAR! GANASTE!");
	}
}
/*/PRE: 
   POST: Ejecuta todo el juego.
/*/
void ejecucion_de_juego(juego_t* juego, char movimiento_ingresado)
{
	while (juego->id_personaje_actual-1 <= juego->tope_personajes && juego->personajes[juego->id_personaje_actual-1].movimientos > 0 && estado_juego(*juego) != -1 && estado_juego(*juego) != 1)
	{
		pedir_movimiento(&movimiento_ingresado);
		realizar_jugada(juego, movimiento_ingresado);
		imprimir_terreno(*juego);
		imprimir_movimientos_restantes(*juego);	
	}
	imprimir_estado_del_juego(*juego);
}

int main(){
	srand ((unsigned)time(NULL));
	juego_t juego;
	char movimiento_ingresado = 'D'; // Inicializacion en valor cualquiera // 
	char contrasenia[MAX_CONTRASENIA];
	increidle(contrasenia);
	bool contrasenia_completa = strcmp (contrasenia, "KRONOS") == 0 ? true : false; 
	inicializar_juego (&juego, contrasenia_completa);
	imprimir_terreno(juego);
	ejecucion_de_juego(&juego, movimiento_ingresado);

	return 0;
}